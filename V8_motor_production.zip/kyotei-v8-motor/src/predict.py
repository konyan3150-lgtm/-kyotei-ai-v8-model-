from __future__ import annotations

import argparse
import re
from pathlib import Path

import joblib
import pandas as pd

from common import FEATURES, wide_to_long, combo_probabilities


def normalize_combo(value: object) -> str | None:
    """Convert 1>2>3 / 1-2-3 / 123 to canonical 1-2-3."""
    if pd.isna(value):
        return None
    s = str(value).strip().replace(' ', '')
    nums = re.findall(r'[1-6]', s)
    if len(nums) != 3 or len(set(nums)) != 3:
        return None
    return '-'.join(nums)


def load_odds(path: str | None, raw: pd.DataFrame, unit: str) -> dict[int, dict[str, float]]:
    """Load trifecta odds in long or wide format.

    Long format examples:
      race_row,COMBO,ODDS
      RACEDATE,PLACE,RACE,COMBO,ODDS

    Wide format example:
      race_row,1-2-3,1-2-4,...

    Returns {race_row: {"1-2-3": decimal_odds, ...}}.
    """
    if not path:
        return {}

    odds = pd.read_csv(path)
    result: dict[int, dict[str, float]] = {}

    def to_decimal(v: object) -> float | None:
        x = pd.to_numeric(v, errors='coerce')
        if pd.isna(x) or float(x) <= 0:
            return None
        x = float(x)
        return x / 100.0 if unit == 'payout100' else x

    # Resolve each odds row to raw CSV race_row.
    def race_ids(frame: pd.DataFrame) -> pd.Series:
        if 'race_row' in frame.columns:
            return pd.to_numeric(frame['race_row'], errors='coerce')
        required = {'RACEDATE', 'PLACE', 'RACE'}
        if not required.issubset(frame.columns):
            raise ValueError(
                'オッズCSVには race_row、または RACEDATE/PLACE/RACE の3列が必要です。'
            )
        left = frame.copy()
        left['_order_idx'] = range(len(left))
        left['RACEDATE'] = pd.to_datetime(left['RACEDATE'], errors='coerce').dt.strftime('%Y-%m-%d')
        right = raw[['RACEDATE', 'PLACE', 'RACE']].copy()
        right['race_row'] = raw.index
        right['RACEDATE'] = pd.to_datetime(right['RACEDATE'], errors='coerce').dt.strftime('%Y-%m-%d')
        merged = left.merge(right, on=['RACEDATE', 'PLACE', 'RACE'], how='left', sort=False)
        merged = merged.sort_values('_order_idx')
        return merged['race_row'].reset_index(drop=True)

    ids = race_ids(odds)

    if {'COMBO', 'ODDS'}.issubset(odds.columns):
        for i, row in odds.reset_index(drop=True).iterrows():
            rid = ids.iloc[i]
            combo = normalize_combo(row['COMBO'])
            dec = to_decimal(row['ODDS'])
            if pd.isna(rid) or combo is None or dec is None:
                continue
            result.setdefault(int(rid), {})[combo] = dec
        return result

    combo_cols = [c for c in odds.columns if normalize_combo(c) is not None]
    if not combo_cols:
        raise ValueError('オッズCSVに COMBO/ODDS 列、または 1-2-3 のような買い目列が見つかりません。')
    for i, row in odds.reset_index(drop=True).iterrows():
        rid = ids.iloc[i]
        if pd.isna(rid):
            continue
        for c in combo_cols:
            dec = to_decimal(row[c])
            if dec is not None:
                result.setdefault(int(rid), {})[normalize_combo(c)] = dec
    return result


def main():
    ap = argparse.ArgumentParser(description='競艇3連単AI予測 + オッズ期待値評価')
    ap.add_argument('csv', help='予測したいレースCSV。学習CSVと同じ事前情報列を含むこと')
    ap.add_argument('--models', default='models')
    ap.add_argument('--top', type=int, default=10, help='表示する上位買い目数')
    ap.add_argument('--odds', help='任意: 3連単オッズCSV')
    ap.add_argument('--odds-unit', choices=['decimal', 'payout100'], default='decimal',
                    help='decimal=6.8倍形式, payout100=680円/100円形式')
    ap.add_argument('--min-ev', type=float, default=1.05,
                    help='期待値候補の最低EV。1.05なら理論回収率105%%以上')
    ap.add_argument('--min-prob', type=float, default=0.005,
                    help='期待値候補の最低AI確率。0.005=0.5%%')
    args = ap.parse_args()

    raw = pd.read_csv(args.csv)
    long = wide_to_long(raw, require_target=False)
    models = {r: joblib.load(Path(args.models) / f'rank{r}.joblib') for r in (1, 2, 3)}
    for r in (1, 2, 3):
        long[f'p{r}'] = models[r].predict_proba(long[FEATURES])[:, 1]

    odds_by_race = load_odds(args.odds, raw, args.odds_unit)

    for rid, g in long.groupby('race_row', sort=False):
        g = g.sort_values('LANE')
        place = raw.loc[rid, 'PLACE'] if 'PLACE' in raw.columns else ''
        race = raw.loc[rid, 'RACE'] if 'RACE' in raw.columns else rid
        print(f'\n=== {place} {race}R ===')
        one = g[['LANE', 'p1', 'p2', 'p3']].copy()
        one[['p1', 'p2', 'p3']] *= 100
        print(one.to_string(index=False, formatters={k: lambda x: f'{x:5.1f}%' for k in ['p1', 'p2', 'p3']}))

        combos = combo_probabilities(g['LANE'].tolist(), g['p1'], g['p2'], g['p3'])
        race_odds = odds_by_race.get(int(rid), {})

        if race_odds:
            scored = []
            for comb, p in combos:
                odds = race_odds.get(comb)
                if odds is None:
                    continue
                ev = p * odds
                scored.append((comb, p, odds, ev, 1.0 / p if p > 0 else float('inf')))

            print('期待値候補（AI確率 × オッズ）:')
            candidates = [x for x in scored if x[3] >= args.min_ev and x[1] >= args.min_prob]
            candidates.sort(key=lambda x: x[3], reverse=True)
            if not candidates:
                print('  条件を満たす買い目なし（見送り候補）')
            for comb, p, odds, ev, breakeven in candidates[:args.top]:
                print(
                    f'  {comb}: AI={p*100:.2f}%  odds={odds:.1f}x  '
                    f'EV={ev:.2f}  損益分岐={breakeven:.1f}x'
                )

            print('AI確率上位:')
            scored.sort(key=lambda x: x[1], reverse=True)
            for comb, p, odds, ev, _ in scored[:args.top]:
                print(f'  {comb}: {p*100:.2f}%  odds={odds:.1f}x  EV={ev:.2f}')
        else:
            print('3連単候補（オッズ未入力のため確率順）:')
            for comb, p in combos[:args.top]:
                print(f'  {comb}: {p*100:.2f}%  公正オッズ目安={1/p:.1f}x')


if __name__ == '__main__':
    main()
