from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from common import FEATURES, combo_probabilities, wide_to_long
from predict import load_odds


def main():
    ap = argparse.ArgumentParser(description='競艇AI v8: キャリブレーション + 見送り判定 + EV表示')
    ap.add_argument('csv')
    ap.add_argument('--models', default='models_v8')
    ap.add_argument('--odds')
    ap.add_argument('--odds-unit', choices=['decimal', 'payout100'], default='decimal')
    ap.add_argument('--top', type=int, default=10)
    ap.add_argument('--min-ev', type=float, default=1.05)
    args = ap.parse_args()

    raw = pd.read_csv(args.csv)
    long = wide_to_long(raw, require_target=False)
    model_dir = Path(args.models)
    rule_path = model_dir / 'selective_rule.json'
    rule = json.loads(rule_path.read_text(encoding='utf-8')) if rule_path.exists() else None

    for rank in (1, 2, 3):
        m = joblib.load(model_dir / f'rank{rank}.joblib')
        cal = joblib.load(model_dir / f'cal_rank{rank}.joblib')
        p = m.predict_proba(long[FEATURES])[:, 1]
        long[f'p{rank}'] = np.clip(cal.predict(p), 1e-6, 1 - 1e-6)

    odds_by_race = load_odds(args.odds, raw, args.odds_unit)

    for rid, g in long.groupby('race_row', sort=False):
        g = g.sort_values('LANE')
        combos = combo_probabilities(g['LANE'].tolist(), g['p1'], g['p2'], g['p3'])
        p1s = np.sort(g['p1'].to_numpy())[::-1]
        top_prob = combos[0][1]
        lane_gap = float(p1s[0] - p1s[1])
        buy_ok = True
        if rule:
            buy_ok = (top_prob >= rule['top_combo_prob_min'] and lane_gap >= rule['top1_lane_gap_min'])

        place = raw.loc[rid, 'PLACE'] if 'PLACE' in raw.columns else ''
        race = raw.loc[rid, 'RACE'] if 'RACE' in raw.columns else rid
        verdict = '購入候補' if buy_ok else '見送り候補'
        print(f'\n=== {place} {race}R | {verdict} ===')
        print(f'AI自信度: top3連単={top_prob*100:.2f}% / 1着差={lane_gap*100:.2f}pt')

        race_odds = odds_by_race.get(int(rid), {})
        if race_odds:
            scored = []
            for combo, p in combos:
                odds = race_odds.get(combo)
                if odds is None:
                    continue
                scored.append((combo, p, odds, p * odds))
            scored.sort(key=lambda x: x[3], reverse=True)
            shown = 0
            for combo, p, odds, ev in scored:
                if ev < args.min_ev:
                    continue
                print(f'  {combo}: AI={p*100:.2f}% odds={odds:.1f}x EV={ev:.2f}')
                shown += 1
                if shown >= args.top:
                    break
            if shown == 0:
                print('  EV条件を満たす買い目なし')
        else:
            for combo, p in combos[:args.top]:
                print(f'  {combo}: {p*100:.2f}% 公正オッズ={1/p:.1f}x')


if __name__ == '__main__':
    main()
