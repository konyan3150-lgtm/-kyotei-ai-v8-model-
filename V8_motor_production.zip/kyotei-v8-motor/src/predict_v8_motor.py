from __future__ import annotations
import argparse,json
from pathlib import Path
import joblib,numpy as np,pandas as pd
from common import FEATURES,combo_probabilities,wide_to_long
from predict import load_odds

def motor_z(g):
    x=((pd.to_numeric(g['MOTORWIN2RATE'],errors='coerce')+pd.to_numeric(g['MOTORWIN3RATE'],errors='coerce'))/2).to_numpy(float)
    good=np.isfinite(x)&(x>0)
    z=np.zeros(len(x))
    if good.sum()>=2:
        sd=x[good].std()
        if sd>1e-9:z[good]=(x[good]-x[good].mean())/sd
    return np.clip(z,-2,2)

def main():
 ap=argparse.ArgumentParser(description='競艇AI v8 実モデル + モーター補正')
 ap.add_argument('csv');ap.add_argument('--models',default='models_v8');ap.add_argument('--odds');ap.add_argument('--odds-unit',choices=['decimal','payout100'],default='decimal');ap.add_argument('--top',type=int,default=10);ap.add_argument('--min-ev',type=float,default=1.05);ap.add_argument('--motor-beta',type=float,default=.08)
 a=ap.parse_args();raw=pd.read_csv(a.csv);long=wide_to_long(raw,require_target=False);md=Path(a.models);rule=json.loads((md/'selective_rule.json').read_text()) if (md/'selective_rule.json').exists() else None
 for r in (1,2,3):
  m=joblib.load(md/f'rank{r}.joblib');cal=joblib.load(md/f'cal_rank{r}.joblib');long[f'p{r}']=np.clip(cal.predict(m.predict_proba(long[FEATURES])[:,1]),1e-6,1-1e-6)
 odds=load_odds(a.odds,raw,a.odds_unit)
 for rid,g in long.groupby('race_row',sort=False):
  g=g.sort_values('LANE').copy();z=motor_z(g);factor=np.exp(a.motor_beta*z)
  for r in (1,2,3):g[f'p{r}']=g[f'p{r}'].to_numpy()*factor
  combos=combo_probabilities(g.LANE.tolist(),g.p1,g.p2,g.p3);p1s=np.sort(g.p1.to_numpy())[::-1];top=combos[0][1];gap=float(p1s[0]-p1s[1]);buy=not rule or(top>=rule['top_combo_prob_min'] and gap>=rule['top1_lane_gap_min'])
  place=raw.loc[rid,'PLACE'] if 'PLACE'in raw else'';race=raw.loc[rid,'RACE'] if 'RACE'in raw else rid;print(f'\n=== {place} {race}R | {"購入候補" if buy else "見送り候補"} | V8実モデル＋モーター補正 ===');print(f'AI自信度: top3連単={top*100:.2f}% / 1着差={gap*100:.2f}pt')
  ro=odds.get(int(rid),{})
  if ro:
   sc=sorted([(c,p,ro[c],p*ro[c]) for c,p in combos if c in ro],key=lambda x:x[3],reverse=True);shown=0
   for c,p,o,ev in sc:
    if ev<a.min_ev:continue
    print(f'  {c}: AI={p*100:.2f}% odds={o:.1f}x EV={ev:.2f}');shown+=1
    if shown>=a.top:break
   if not shown:print('  EV条件を満たす買い目なし')
  else:
   for c,p in combos[:a.top]:print(f'  {c}: {p*100:.2f}% 公正オッズ={1/p:.1f}x')
if __name__=='__main__':main()
