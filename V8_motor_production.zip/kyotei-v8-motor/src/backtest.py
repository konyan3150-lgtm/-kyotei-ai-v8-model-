from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import pandas as pd

from common import FEATURES, wide_to_long, combo_probabilities, parse_order


def canonical_result(value: object) -> str | None:
    order = parse_order(value)
    if not order or len(order) < 3:
        return None
    return '-'.join(map(str, order[:3]))


def main():
    ap = argparse.ArgumentParser(description='3連単予測のテスト期間バックテスト')
    ap.add_argument('csv', help='学習用CSV（RENTAN3/RENTAN3K/splitを含む）')
    ap.add_argument('--models', default='models')
    ap.add_argument('--top-k', type=int, default=5, help='1レースあたり確率上位何点を買うか')
    ap.add_argument('--stake', type=int, default=100, help='1点あたり投資額（円）')
    ap.add_argument('--split', default='test', help='評価対象 split。既定値=test')
    args = ap.parse_args()

    raw = pd.read_csv(args.csv)
    required = {'RENTAN3', 'RENTAN3K', 'split'}
    missing = required - set(raw.columns)
    if missing:
        raise ValueError(f'バックテストに必要な列がありません: {sorted(missing)}')

    eval_raw = raw[raw['split'].astype(str).eq(args.split)].copy()
    long = wide_to_long(raw, require_target=False)
    eval_long = long[long['split'].astype(str).eq(args.split)].copy()

    models = {r: joblib.load(Path(args.models) / f'rank{r}.joblib') for r in (1, 2, 3)}
    for r in (1, 2, 3):
        eval_long[f'p{r}'] = models[r].predict_proba(eval_long[FEATURES])[:, 1]

    races = hits = 0
    bet = returned = 0.0
    rows = []
    for rid, g in eval_long.groupby('race_row', sort=False):
        actual = canonical_result(raw.loc[rid, 'RENTAN3'])
        payout = pd.to_numeric(raw.loc[rid, 'RENTAN3K'], errors='coerce')
        if actual is None or pd.isna(payout):
            continue

        combos = combo_probabilities(g['LANE'].tolist(), g['p1'], g['p2'], g['p3'])[:args.top_k]
        picks = [c for c, _ in combos]
        hit = actual in picks
        race_bet = args.stake * len(picks)
        race_return = float(payout) * (args.stake / 100.0) if hit else 0.0

        races += 1
        hits += int(hit)
        bet += race_bet
        returned += race_return
        rows.append({
            'race_row': rid,
            'RACEDATE': raw.loc[rid, 'RACEDATE'],
            'PLACE': raw.loc[rid, 'PLACE'],
            'RACE': raw.loc[rid, 'RACE'],
            'actual': actual,
            'picks': ','.join(picks),
            'hit': int(hit),
            'bet_yen': race_bet,
            'return_yen': race_return,
        })

    roi = returned / bet if bet else float('nan')
    hit_rate = hits / races if races else float('nan')
    profit = returned - bet

    print(f'評価split: {args.split}')
    print(f'レース数: {races:,}')
    print(f'1レース買い目: 上位{args.top_k}点 × {args.stake}円')
    print(f'的中レース: {hits:,} ({hit_rate*100:.2f}%)')
    print(f'投資額: {bet:,.0f}円')
    print(f'払戻額: {returned:,.0f}円')
    print(f'損益: {profit:,.0f}円')
    print(f'回収率: {roi*100:.2f}%')

    out = Path(args.models) / f'backtest_top{args.top_k}.csv'
    pd.DataFrame(rows).to_csv(out, index=False)
    print(f'明細保存: {out}')


if __name__ == '__main__':
    main()
