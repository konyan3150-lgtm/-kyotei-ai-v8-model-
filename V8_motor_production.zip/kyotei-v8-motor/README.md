# AI競艇 v8

`boatrace_training.csv` のレース前情報だけを使って、1着・2着・3着を別々に推定し、3連単120通りをランキングする競艇予想AIです。

v8では、前版の「確率順 + EV表示」に加えて、次の2点を追加しました。

1. **時系列を守った確率キャリブレーション**
   - train: 2024-04-01〜2024-12-31
   - validate: 2025-01-01〜2025-02-13
   - test: 2025-02-14〜2025-03-31
   - trainだけでモデル学習 → validateでIsotonic calibration → testで最終評価

2. **買う/見送る判定**
   - validate期間だけで単純な自信度しきい値を選択
   - その固定ルールをtest期間にそのまま適用
   - テスト結果を見てからしきい値を調整しないため、過学習を抑える構成

## v8テスト結果

学習データ: 55,301レース / 94列

- 1着艇 race-pick accuracy: **56.86%**
- 2着艇 race-pick accuracy: **28.12%**
- 3着艇 race-pick accuracy: **22.61%**
- 3連単1点完全一致: **7.87%**

### 3連単上位3点を各100円買うバックテスト

**test全レース**

- 6,998レース
- 的中率: 20.73%
- 回収率: **77.53%**

**v8の見送りルール適用後**

- 376レースだけ購入
- 的中率: **32.71%**
- 回収率: **76.60%**

見送り判定で的中率は上がりましたが、回収率100%には届いていません。したがって、現時点のv8は「利益が出るAI」とは扱いません。

## 学習

```bash
pip install -r requirements.txt
python src/train_v8.py /path/to/boatrace_training.csv --out models_v8
```

## 見送りルール検証

```bash
python src/selective_backtest_v8.py /path/to/boatrace_training.csv \
  --models models_v8 \
  --top-k 3 \
  --stake 100 \
  --min-races 300
```

生成物:

- `models_v8/selective_rule.json`
- `models_v8/backtest_v8_selected_test.csv`
- `models_v8/v8_rule_candidates.csv`

## v8予測

オッズなし:

```bash
python src/predict_v8.py upcoming_races.csv --models models_v8 --top 10
```

オッズあり:

```bash
python src/predict_v8.py upcoming_races.csv \
  --models models_v8 \
  --odds trifecta_odds.csv \
  --min-ev 1.05 \
  --top 10
```

表示内容:

- 「購入候補 / 見送り候補」
- AI自信度
- 3連単AI確率
- 公正オッズ
- オッズ入力時はEV（AI確率 × オッズ）

## 情報漏洩対策

`TAN`, `TANK`, `RENTAN2`, `RENTAN2K`, `RENTAN3`, `RENTAN3K` は学習特徴量に使っていません。結果と払戻はバックテスト評価だけに使用します。

## 次にやること（v8.1候補）

- 展示タイム
- 直前ST
- 進入/コース取り
- 風向・風速・波高
- 水面/開催場ごとの補正
- 選手×場、モーター×場などの相互作用特徴量
- 3連単の直接学習または順位学習
- 実オッズ履歴を使った、本当のEVバックテスト

現在のCSVには「各買い目の締切前オッズ履歴」がないため、過去の全120通りについて正確なEV検証はできません。`RENTAN3K` は的中した組み合わせの払戻だけなので、未来情報として学習には使っていません。

> このAIは予測・検証用です。実際の投票では予算上限を決め、損失を取り戻す目的の追加投票は避けてください。

## V8実モデル＋モーター補正
`src/predict_v8_motor.py` を追加。V8実モデルの推論後に、同一レース内のモーター2連率・3連率の平均を標準化し、指数係数（既定 beta=0.08、zは±2でクリップ）で各着順確率を穏やかに補正します。元V8モデルは保持し、ロールバック可能です。

```bash
python src/predict_v8_motor.py upcoming_races.csv --models models_v8 --top 10
```
